for (const x = 0 in y){}
