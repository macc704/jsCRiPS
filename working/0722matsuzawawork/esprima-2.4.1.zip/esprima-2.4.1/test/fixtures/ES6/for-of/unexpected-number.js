for (const of 42);
