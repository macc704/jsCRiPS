for (let z of list);
