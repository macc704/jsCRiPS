for (const {x, y} of z);
