for ([p, q] of r);
