for (const x = 1 of y);
