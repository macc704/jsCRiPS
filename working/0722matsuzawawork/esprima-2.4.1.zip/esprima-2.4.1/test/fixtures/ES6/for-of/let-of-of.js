for (let of of xyz);
