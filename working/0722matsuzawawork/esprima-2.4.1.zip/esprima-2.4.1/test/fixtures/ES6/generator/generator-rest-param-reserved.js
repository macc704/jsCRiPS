(function*(...yield) {})
