(function() { yield 3; })
