(function*(x, y, z) { yield* x; })
