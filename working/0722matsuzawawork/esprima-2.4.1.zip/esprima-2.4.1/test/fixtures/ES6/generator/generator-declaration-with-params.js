function *foo(x, y, z) {}
