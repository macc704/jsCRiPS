(function*() {
    function*({x: y = yield 3}) {}
})
