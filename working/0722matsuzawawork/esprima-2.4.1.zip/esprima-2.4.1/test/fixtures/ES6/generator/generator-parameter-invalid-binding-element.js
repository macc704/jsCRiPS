(function*() {
    function*(x = yield 3) {}
})
