(function*() {
    function*({[yield 3]: y}) {}
})
