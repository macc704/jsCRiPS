(function*({x: yield}) {})
