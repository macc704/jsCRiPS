(function*(...x) {})
