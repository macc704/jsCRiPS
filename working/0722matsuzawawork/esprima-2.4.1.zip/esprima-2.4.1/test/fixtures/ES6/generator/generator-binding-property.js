(function*(z) {
    var {x: y = yield 3} = z;
})
