(function*(x, y, z) {})
