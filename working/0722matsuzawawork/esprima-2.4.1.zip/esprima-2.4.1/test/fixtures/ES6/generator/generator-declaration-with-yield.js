function *foo() { yield 3; }
