(function*({yield}) {})
