function a([a=0]) {}
