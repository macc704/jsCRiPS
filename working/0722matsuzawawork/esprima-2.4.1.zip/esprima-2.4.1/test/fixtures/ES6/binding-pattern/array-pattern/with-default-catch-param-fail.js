try { } catch ([a] = []) { }
