try {} catch ([a,b, {c, d:e=0, [f]:g=0, h=i}]) {}
