export {foo, bar} from "foo";
