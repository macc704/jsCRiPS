export {foo as default} from "foo";
