import {default as foo} from "foo";
