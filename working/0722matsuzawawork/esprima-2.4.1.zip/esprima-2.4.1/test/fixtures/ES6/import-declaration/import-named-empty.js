import {} from "foo";
