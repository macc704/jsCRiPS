import foo, * as bar from "foo";
