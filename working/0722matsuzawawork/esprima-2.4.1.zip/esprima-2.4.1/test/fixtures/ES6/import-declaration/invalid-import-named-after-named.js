import {bar}, {foo} from "foo";
