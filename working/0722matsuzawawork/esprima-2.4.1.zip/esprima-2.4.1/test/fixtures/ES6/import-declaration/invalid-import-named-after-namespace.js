import * as foo, {bar} from "foo";
