import * as foo from "foo";
