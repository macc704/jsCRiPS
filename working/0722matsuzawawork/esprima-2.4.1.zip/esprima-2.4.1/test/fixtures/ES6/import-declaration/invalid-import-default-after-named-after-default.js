import foo, {bar}, foo from "foo";
