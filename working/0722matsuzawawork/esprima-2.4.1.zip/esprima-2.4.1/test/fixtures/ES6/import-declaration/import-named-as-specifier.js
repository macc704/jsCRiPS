import {bar as baz} from "foo";
