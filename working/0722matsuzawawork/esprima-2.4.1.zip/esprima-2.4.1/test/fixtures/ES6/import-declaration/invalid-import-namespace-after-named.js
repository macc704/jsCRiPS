import {bar}, * as foo from "foo";
