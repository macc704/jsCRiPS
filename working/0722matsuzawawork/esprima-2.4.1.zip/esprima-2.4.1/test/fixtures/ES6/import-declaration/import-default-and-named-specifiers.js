import foo, {bar} from "foo";
