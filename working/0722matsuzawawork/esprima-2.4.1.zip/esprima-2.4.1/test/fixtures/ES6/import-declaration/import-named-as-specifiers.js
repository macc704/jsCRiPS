import {bar as baz, xyz} from "foo";
