if (cond)
// Leading to EmptyStatement
    ;    // Trailing to EmptyStatement
