if (cond)
    // Leading to if-block
{
    print('hello');
}    // Trailing to if-block
