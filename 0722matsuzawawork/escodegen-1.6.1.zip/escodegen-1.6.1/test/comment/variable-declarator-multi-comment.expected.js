function test() {
    var
        /*
         * Leading to VariableDeclarator
         * Leading to VariableDeclarator
         */
        i = 20,
        /*
         * Leading to VariableDeclarator
         * Leading to VariableDeclarator
         */
        j = 20;
}
