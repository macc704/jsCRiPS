try{}//
finally{}

try{}
catch(e){}//
finally{}

{
try{}
catch(e){}//
finally{}
}
