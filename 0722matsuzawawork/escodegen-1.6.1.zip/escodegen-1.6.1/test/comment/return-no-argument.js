(function() {
    return;  // comment
}());
