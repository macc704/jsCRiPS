function test() {
// Leading to EmptyStatement
;
                    // Trailing to EmptyStatement
}
