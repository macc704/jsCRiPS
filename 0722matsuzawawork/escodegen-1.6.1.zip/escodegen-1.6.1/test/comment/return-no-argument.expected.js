(function () {
    return;    // comment
}());
