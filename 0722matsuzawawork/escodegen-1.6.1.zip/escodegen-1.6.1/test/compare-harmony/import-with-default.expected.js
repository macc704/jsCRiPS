import foo from 'foo';
import foo, * as foo from 'foo';
import * as foo from 'foo';
import ok, {
    foo as bar,
    test as testing,
    logging
} from 'foo';
