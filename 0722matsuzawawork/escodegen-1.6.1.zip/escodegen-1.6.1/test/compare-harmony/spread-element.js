var [a,  b, ...rest] = array;
const [a, b, ...rest] = array;
