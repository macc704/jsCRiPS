var escaped = `
\u2028
\u2029
`;

var escaped = `
\v
\b
\t
\n
\r
`;
