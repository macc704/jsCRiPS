var hello = `hello`;
var hello = `
line
terminators`;
var tagged = tagged`hello`;
var tagged = member.call`hello`;
var tagged = new call`hello`();
var tagged = new (call`hello`())();
var tageed = member[call`hello`];
var middles = `
Is the order a rabbit?
`;
var middles = `
Is the order ${ order }?
`;
var middles = `
Is the order ${ order }?
`;
var middles = `
1. ${ cocoa }
2. ${ chino }
3. ${ rize }
4. ${ syaro }
5. ${ chiya }
`;
