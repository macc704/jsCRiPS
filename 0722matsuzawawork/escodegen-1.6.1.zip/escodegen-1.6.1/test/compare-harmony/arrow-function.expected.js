e => {
    print('hello world');
};
(e1, e2, e3) => {
    print('hello world');
};
e => e;
(e1, e2, e3) => e;
e => {
};
e => 20 + 20;
