export default function a () { }
// export default var i = 20;
// export default const K = 20;
