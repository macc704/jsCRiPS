var x;

var y = 5;

var z = 10;