var foo = function () {
    var a = 0;

    var b = 1;  // test
};