var foo = function () {
    // comment before code in function
    var x = 5;
};