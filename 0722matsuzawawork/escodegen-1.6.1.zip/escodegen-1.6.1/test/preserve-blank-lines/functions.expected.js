var foo = function () {
    var a;
};

function bar() {
    var b;
}

var empty_foo = function () {
    
};

function empty_bar() {
    // TODO: implement this function
}

foo();

bar();