/* single line block comment */

var x;

// single line comment

var y = 5;  // comment after code

var z = 10;

var foo = function () {
    var a = 0;

    // single line comment in function

    var b = 1;  // commdent after code in a function

    var c = 2;
};