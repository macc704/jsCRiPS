// comment 1
// comment 2
// comment 3
var a = 5;