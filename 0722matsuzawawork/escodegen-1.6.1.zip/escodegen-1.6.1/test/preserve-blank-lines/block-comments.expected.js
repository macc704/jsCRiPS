var x;  /* block comment after code */

var y = 5;

/* block comment in between lines */

var z = 10;

/**
 *  multiline block comment
 */

var foo = function () {
    var a = 0;

    /* block comment in a function */

    var b = 1;

    /**
     * multiline block comment in a function
     */
};