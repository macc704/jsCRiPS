export * from 'OK';
export {
    name
} from 'OK';
export {
    a as b,
    c as d
} from 'hello';
export {
    a as b,
    c as d
};
export { };
export default i = 20;
export function test() {
}
export var i = 20;
export let i = 42;
