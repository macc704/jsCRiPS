delete delete i;
+ +i;
!!i;
+ ++i;
- --i;
