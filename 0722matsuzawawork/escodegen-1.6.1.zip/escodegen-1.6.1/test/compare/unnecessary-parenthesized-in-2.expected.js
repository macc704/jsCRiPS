var i = 1 * (2 + 0 in []);
for (var i = 1 * (2 + 0 in []) in []);
