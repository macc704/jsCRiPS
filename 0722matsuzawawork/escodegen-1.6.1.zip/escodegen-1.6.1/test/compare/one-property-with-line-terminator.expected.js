dejavu.Class.declare({
    method2: function () {
    }
});
